"""Modularized CHAMINAI Streamlit application."""
